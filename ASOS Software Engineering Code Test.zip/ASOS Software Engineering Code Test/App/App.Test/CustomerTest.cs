﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using App;
namespace App.Test
{
    [TestClass]
    public class CustomerTest
    {
        [TestMethod]
        public void Test_That_Customer_Without_First_Name_Returns_False()
        {
            var x = new CustomerService(new CompanyRepository());
            Assert.IsFalse(x.AddCustomer("", "", "fake", DateTime.Now, 0));
        }
    }
}
