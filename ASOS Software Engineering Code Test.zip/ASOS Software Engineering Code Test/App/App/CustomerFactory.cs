﻿using App.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace App
{
   public  class CustomerFactory: ICustomerFactory
    {
        // could inject repository here
        public CustomerFactory()
        {

        }
        public Customer CreateCustomer(DateTime dob, string email, string firstname, string lastname, Company company)
        {
         return   new Customer
            {
                Company = company,
                DateOfBirth = dob,
                EmailAddress = email,
                Firstname = firstname,
                Surname = lastname
            };
        }
    }
}
