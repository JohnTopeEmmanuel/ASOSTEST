﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace App.Interface
{
    //todo: use Unity container to map interfaces to implementations

    public interface ICustomerFactory
    {

         Customer CreateCustomer( DateTime dob, string email, string firstname, string lastname, Company company);
    }
}
