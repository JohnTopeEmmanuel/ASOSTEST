﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace App.Interface
{
    //todo: use Unity container to map interfaces to implementations

    public interface ICompanyRepository
    {
        Company GetById(int id);
    }
}
