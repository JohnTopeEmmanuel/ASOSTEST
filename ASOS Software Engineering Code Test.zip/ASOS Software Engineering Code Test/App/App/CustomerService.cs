﻿using App.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace App
{
    public class CustomerService
    {
        //todo: use Unity container to map interfaces to implementations
        // these ie VeryImportant and Important could be enums or moved to a different class or config file
        private const string VeryImportant = "VeryImportantClient";
        private const string Important = "ImportantClient";
        ICompanyRepository _repository;
        ICustomerFactory _customerFactory;
        public CustomerService( ICompanyRepository repository, ICustomerFactory customerFactory)
        {
            _repository = repository;
            _customerFactory = customerFactory;
        }

        public bool AddCustomer(string firstname, string surname, string email, DateTime dateOfBirth, int companyId)
        {
            if (string.IsNullOrEmpty(firstname) || string.IsNullOrEmpty(surname))
            {
                return false;
            }

            if (!email.Contains("@") && !email.Contains("."))
            {
                return false;
            }

            var now = DateTime.Now;
            int age = now.Year - dateOfBirth.Year;
            if (now.Month < dateOfBirth.Month || (now.Month == dateOfBirth.Month && now.Day < dateOfBirth.Day)) age--;

            if (age < 21)
            {
                return false;
            }
            var company = _repository.GetById(companyId);

            var customer = _customerFactory.CreateCustomer(0, dateOfBirth, email, firstname, surname, company);

            AssingnCustomerCredit(company, customer);

            if (customer.HasCreditLimit && customer.CreditLimit < 500)
            {
                return false;
            }

            CustomerDataAccess.AddCustomer(customer);

            return true;
        }

        // maybe not static
        private static void AssingnCustomerCredit(Company company, Customer customer)
        {
            if (company.Name == VeryImportant)
            {
                // Skip credit check
                customer.HasCreditLimit = false;
            }
            else if (company.Name == Important)
            {
                // Do credit check and double credit limit
                customer.HasCreditLimit = true;
                using (var customerCreditService = new CustomerCreditServiceClient())
                {
                    var creditLimit = customerCreditService.GetCreditLimit(customer.Firstname, customer.Surname, customer.DateOfBirth);
                    creditLimit = creditLimit * 2;
                    customer.CreditLimit = creditLimit;
                }
            }
            else
            {
                // Do credit check
                customer.HasCreditLimit = true;
                using (var customerCreditService = new CustomerCreditServiceClient())
                {
                    var creditLimit = customerCreditService.GetCreditLimit(customer.Firstname, customer.Surname, customer.DateOfBirth);
                    customer.CreditLimit = creditLimit;
                }
            }
        }
    }
}
